package com.example.aivideoworkshop

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaExtractor
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.math.max

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { VideoWorkshopScreen(this) } }
    }
}

@Composable
private fun VideoWorkshopScreen(activity: MainActivity) {
    val context = activity
    val scope = rememberCoroutineScope()
    var images by remember { mutableStateOf(listOf<Uri>()) }
    var music by remember { mutableStateOf<Uri?>(null) }
    var script by remember { mutableStateOf("老板|六米一件。\n顾客|隔壁才三米一件，你会做生意吗？\n老板|规矩不能坏。") }
    var musicVolume by remember { mutableFloatStateOf(0.12f) }
    var status by remember { mutableStateOf("先选择图片，再编辑人物对白。") }
    var busy by remember { mutableStateOf(false) }
    var outputUri by remember { mutableStateOf<Uri?>(null) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { images = it }
    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { music = it }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("AI 视频工坊 Lite", style = MaterialTheme.typography.headlineMedium)
        Text("荣耀 Play7T 适配 · 本地制作 · 4:3 MP4")
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("第一步：导入剧情图片", style = MaterialTheme.typography.titleMedium)
                Button(onClick = { imagePicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("选择图片（${images.size} 张）") }
                Text("建议按剧情顺序选择 2–10 张图片。")
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("第二步：人物对白", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(value = script, onValueChange = { script = it }, modifier = Modifier.fillMaxWidth().height(190.dp), label = { Text("每行格式：人物|台词") })
                Text("不同人物会用不同音高合成语音。声音品质取决于手机已安装的中文 TTS 引擎。")
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("第三步：背景音乐（可选）", style = MaterialTheme.typography.titleMedium)
                Button(onClick = { musicPicker.launch("audio/*") }, modifier = Modifier.fillMaxWidth()) { Text(if (music == null) "选择手机音乐" else "已选择背景音乐，更换") }
                Text("音乐音量：${(musicVolume * 100).toInt()}%")
                Slider(value = musicVolume, onValueChange = { musicVolume = it }, valueRange = 0f..0.5f)
            }
        }
        Button(enabled = !busy && images.isNotEmpty() && script.isNotBlank(), onClick = {
            busy = true; outputUri = null; status = "正在准备语音…"
            scope.launch {
                try {
                    val result = withContext(Dispatchers.IO) { createLocalVideo(context, images, music, script, musicVolume) }
                    outputUri = result
                    status = "制作完成！视频已保存到 Movies/AI视频工坊。"
                } catch (e: Exception) {
                    status = "制作失败：${e.message ?: "未知错误"}"
                } finally { busy = false }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "正在制作，请保持应用打开…" else "生成 4:3 MP4 视频") }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(status, style = MaterialTheme.typography.bodyMedium)
        outputUri?.let { uri ->
            Button(onClick = {
                val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                context.startActivity(intent)
            }, modifier = Modifier.fillMaxWidth()) { Text("预览成品视频") }
            Button(onClick = {
                val intent = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                context.startActivity(Intent.createChooser(intent, "分享视频"))
            }, modifier = Modifier.fillMaxWidth()) { Text("分享 MP4") }
        }
        Text("说明：本版本是静态图片镜头运动，不是生成式 AI 动态视频；人物由你在台词中标注，字幕根据台词生成，不会自动识别照片中的人物身份。", style = MaterialTheme.typography.bodySmall)
    }
}

private data class Line(val character: String, val text: String)

private suspend fun createLocalVideo(context: Context, imageUris: List<Uri>, musicUri: Uri?, rawScript: String, musicVolume: Float): Uri {
    require(imageUris.isNotEmpty()) { "请先选择图片" }
    val lines = rawScript.lines().mapNotNull { row ->
        val split = row.split("|", limit = 2)
        if (split.size == 2 && split[1].isNotBlank()) Line(split[0].trim().ifBlank { "旁白" }, split[1].trim()) else null
    }
    require(lines.isNotEmpty()) { "请至少输入一行 人物|台词" }
    val work = File(context.cacheDir, "render_${UUID.randomUUID()}").apply { mkdirs() }
    try {
        val localImages = imageUris.take(12).mapIndexed { i, uri -> copyUri(context, uri, File(work, "image_$i" + extensionFor(context, uri))) }
        val ready = CompletableDeferred<Unit>()
        val tts = withContext(Dispatchers.Main) {
            TextToSpeech(context) { code ->
                if (code == TextToSpeech.SUCCESS) ready.complete(Unit)
                else ready.completeExceptionally(IllegalStateException("手机语音引擎初始化失败"))
            }
        }
        try {
            ready.await()
            tts.language = Locale.SIMPLIFIED_CHINESE
            val audioFiles = mutableListOf<File>()
            val durations = mutableListOf<Double>()
            val roleOrder = lines.map { it.character }.distinct().withIndex().associate { it.value to it.index }
            for ((index, line) in lines.withIndex()) {
                val file = File(work, "voice_$index.wav")
                // 角色音色以音高做轻量区分；不代表不同真人音色克隆。
                tts.setPitch(if ((roleOrder[line.character] ?: 0) % 2 == 0) 0.88f else 1.12f)
                tts.setSpeechRate(1.0f)
                val done = CompletableDeferred<Unit>()
                val utteranceId = "u_$index"
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { if (id == utteranceId && !done.isCompleted) done.complete(Unit) }
                    @Deprecated("Deprecated in Java") override fun onError(id: String?) { if (id == utteranceId && !done.isCompleted) done.completeExceptionally(IllegalStateException("语音合成失败：${line.character}")) }
                    override fun onError(id: String?, errorCode: Int) { if (id == utteranceId && !done.isCompleted) done.completeExceptionally(IllegalStateException("语音合成失败：${line.character}（$errorCode）")) }
                })
                val result = tts.synthesizeToFile(line.text, Bundle(), file, utteranceId)
                check(result == TextToSpeech.SUCCESS) { "无法生成第 ${index + 1} 段配音" }
                done.await()
                audioFiles.add(file)
                durations.add(mediaDurationSeconds(file).coerceAtLeast(0.8))
            }
            val srt = File(work, "captions.srt")
            var clock = 0.0
            srt.writeText(lines.mapIndexed { i, line ->
                val start = clock
                val end = clock + durations[i]
                clock = end + 0.18
                "${i + 1}\n${srtTime(start)} --> ${srtTime(end)}\n${line.character}：${line.text}\n"
            }.joinToString("\n"), Charsets.UTF_8)
            val totalDuration = max(clock, 3.0)
            val perImage = totalDuration / localImages.size
            val args = mutableListOf<String>()
            localImages.forEach { image -> args += listOf("-loop", "1", "-t", ff(perImage), "-i", image.absolutePath) }
            audioFiles.forEach { audio -> args += listOf("-i", audio.absolutePath) }
            val musicFile = musicUri?.let { copyUri(context, it, File(work, "music" + extensionFor(context, it))) }
            if (musicFile != null) args += listOf("-stream_loop", "-1", "-i", musicFile.absolutePath)
            val filters = mutableListOf<String>()
            val videoLabels = localImages.indices.map { i ->
                filters += "[$i:v]scale=1024:768:force_original_aspect_ratio=increase,crop=1024:768,zoompan=z='min(zoom+0.0005,1.06)':d=1:s=1024x768:fps=25,setsar=1,format=yuv420p[v$i]"
                "[v$i]"
            }
            filters += videoLabels.joinToString("") + "concat=n=${localImages.size}:v=1:a=0[vout]"
            val audioLabels = mutableListOf<String>()
            var offsetMs = 0.0
            audioFiles.indices.forEach { i ->
                val inputIndex = localImages.size + i
                val delay = (offsetMs * 1000).toLong()
                filters += "[$inputIndex:a]adelay=$delay|$delay,volume=1.0[a$i]"
                audioLabels += "[a$i]"
                offsetMs += durations[i] + 0.18
            }
            if (musicFile != null) {
                val musicIndex = localImages.size + audioFiles.size
                filters += "[$musicIndex:a]volume=${musicVolume.coerceIn(0f, 0.5f)}[bg]"
                audioLabels += "[bg]"
            }
            filters += audioLabels.joinToString("") + "amix=inputs=${audioLabels.size}:duration=longest:dropout_transition=1[aout]"
            val srtEscaped = srt.absolutePath.replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
            filters += "[vout]subtitles='$srtEscaped':force_style='FontName=Noto Sans CJK SC,FontSize=26,Outline=2,Shadow=1,Alignment=2,MarginV=28'[vfinal]"
            val output = File(work, "finished.mp4")
            val command = buildString {
                append("-y ")
                args.forEach { append(quote(it)).append(' ') }
                append("-filter_complex ").append(quote(filters.joinToString(";"))).append(' ')
                append("-map [vfinal] -map [aout] -c:v libx264 -preset ultrafast -crf 25 -r 25 -pix_fmt yuv420p -c:a aac -b:a 128k -shortest ")
                append(quote(output.absolutePath))
            }
            val session = CompletableDeferred<Boolean>()
            FFmpegKit.executeAsync(command) { s ->
                if (ReturnCode.isSuccess(s.returnCode)) session.complete(true)
                else session.completeExceptionally(IllegalStateException("FFmpeg 合成失败：${s.failStackTrace ?: s.allLogsAsString.takeLast(1200)}"))
            }
            check(session.await())
            saveToMovies(context, output)
        } finally { tts.stop(); tts.shutdown() }
    } finally { work.deleteRecursively() }
}

private fun copyUri(context: Context, uri: Uri, target: File): File {
    context.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use(input::copyTo) } ?: error("无法读取所选文件")
    return target
}
private fun extensionFor(context: Context, uri: Uri): String {
    val type = context.contentResolver.getType(uri).orEmpty()
    return when { type.contains("png") -> ".png"; type.contains("webp") -> ".webp"; type.contains("mp4") -> ".mp4"; type.contains("mpeg") || type.contains("mp3") -> ".mp3"; type.contains("wav") -> ".wav"; else -> ".jpg" }
}
private fun mediaDurationSeconds(file: File): Double {
    val extractor = MediaExtractor()
    return try {
        extractor.setDataSource(file.absolutePath)
        var duration = 1.0
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            if (format.containsKey(android.media.MediaFormat.KEY_DURATION)) {
                duration = format.getLong(android.media.MediaFormat.KEY_DURATION) / 1_000_000.0
                break
            }
        }
        duration
    } finally { extractor.release() }
}
private fun saveToMovies(context: Context, source: File): Uri {
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "AI视频_${System.currentTimeMillis()}.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AI视频工坊")
        put(MediaStore.Video.Media.IS_PENDING, 1)
    }
    val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: error("无法创建相册视频文件")
    try {
        context.contentResolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out) } } ?: error("无法写入视频")
        values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
        context.contentResolver.update(uri, values, null, null)
        return uri
    } catch (e: Exception) { context.contentResolver.delete(uri, null, null); throw e }
}
private fun srtTime(seconds: Double): String {
    val ms = (seconds * 1000).toLong().coerceAtLeast(0)
    val h = ms / 3600000; val m = (ms % 3600000) / 60000; val s = (ms % 60000) / 1000; val milli = ms % 1000
    return "%02d:%02d:%02d,%03d".format(h, m, s, milli)
}
private fun ff(value: Double) = String.format(Locale.US, "%.3f", value)
private fun quote(value: String) = "'" + value.replace("'", "'\\''") + "'"
