plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.example.aivideoworkshop"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.aivideoworkshop"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1-lite"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation(platform("androidx.compose:compose-bom:2025.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.arthenica:ffmpeg-kit-full:6.0-2")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
