# AI 视频工坊 Lite（荣耀 Play7T 适配源码）

面向 Android 12+ 的轻量本地制作版。核心处理在手机本地完成，不需要账号或付费 API。

## 功能
- 多张图片导入，固定 4:3 画幅，Ken Burns 轻微推近效果
- 按 `人物|台词` 输入多角色对白
- 使用 Android 系统 TTS 合成对白音频；通过音高差异区分角色（不是克隆/身份识别）
- 根据台词生成并烧录中文字幕
- 可选导入本地背景音乐并调节音量
- FFmpeg 合成 MP4，保存到系统 Movies/AI视频工坊

## 真实能力边界
此 Lite 版不是生成式 AI 图生视频：它把静态图片做成有镜头运动的短片。手机端不运行大型视频扩散模型。自动人脸识别/身份识别没有包含；角色由用户在对白中标注。字幕来自用户输入的台词，不是自动语音识别。语音由手机已安装的 TTS 引擎提供，音色/中文语音包取决于设备。若手机没有中文语音包，请在系统文字转语音设置中安装。

## 用 Android Studio 编译 APK
1. Android Studio 打开 `android/`。
2. 安装 Android SDK 35、JDK 17。
3. 等待 Gradle 同步，连接荣耀 Play7T，点 Run。
4. 生成 APK：Build > Build Bundle(s) / APK(s) > Build APK(s)。

工程使用 FFmpegKit 6.0-2 进行本地视频合成。FFmpegKit 上游已停止维护，依赖仓库或新系统兼容性可能变化；若 Gradle 无法解析该依赖，需要替换为自行构建且具备相同滤镜能力的 FFmpeg Android AAR。该依赖体积较大，APK 体积会明显增加。

## 使用
1. 在 APP 中选择图片（建议 2-10 张）。
2. 每行输入一段对白：`老板|六米一件。`、`顾客|隔壁才三米一件，你会做生意吗？`
3. 可选选择 MP3/M4A 背景音乐。
4. 点击生成，等待本地合成。成品保存到系统相册/Movies/AI视频工坊。

## 兼容性建议
Play7T 8GB RAM / 128GB：建议单次 2-10 张图片，先用 720p/25fps（本项目输出 1024x768/25fps）；确保剩余存储至少 2-3GB。处理期间保持 APP 在前台，避免系统回收。

## 云端免费编译（可用手机浏览器操作，但需要 GitHub 账号）
项目包含 `.github/workflows/build-apk.yml`。将源码提交到 GitHub 仓库后，在仓库 Actions 页面运行 `Build Android APK`，成功后下载名为 `AI-Video-Workshop-Play7T-debug-apk` 的构建产物。Debug APK 仅用于测试安装，不是 Play 商店发布签名包。GitHub Actions 的免费额度受账号和仓库类型限制。
